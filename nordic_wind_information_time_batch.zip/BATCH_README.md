# Information-Time Audit Batch

Copy the folders in this package into the repository root.

Run the tests:

```powershell
$env:PYTHONPATH="src"
py -m pytest -q
```

Run the example audit:

```powershell
$env:PYTHONPATH="src"
py -m nordic_wind.audit_dataset `
  --input sample_data/information_time_example.csv `
  --contract configs/dataset_contract.example.json
```

Expected result: 3 rows, 2 available at decision, 1 violation.
